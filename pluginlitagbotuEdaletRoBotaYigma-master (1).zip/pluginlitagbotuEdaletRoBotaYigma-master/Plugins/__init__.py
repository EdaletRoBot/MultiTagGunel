from telethon import TelegramClient 
import logging
from Plugins.komekci.edaletconfig import edalet

logging.basicConfig(format='[%(levelname) 5s/%(asctime)s] %(name)s: %(message)s',
                    level=logging.INFO)
